# hi_tw

Hindi translation words, from https://git.door43.org/BCS-EXEGETICAL/hi_tw
STR https://git.door43.org/Door43/SourceTextRequestForm/issues/147